#! /bin/bash
# Afficher un menu pour réaliser des opérations sur les fichiers .sh
#
# On "charge" les fonctions qui sont dans un fichier secondaire
source fonctions.fonc

while true; do
	# Affichage du menu
	f_menu
	read choix

	case $choix in
		B)
			f_sauvegarder
			;;
		D)
			f_supprimer
			;;
		L)
			f_lister
			;;
		Q)
			exit 0
			;;
	esac
done
